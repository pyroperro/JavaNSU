package calculator.commands;
import calculator.Context;

public class Progression implements Command {
    @Override
    public void execute(Context context, String[] args) {
        if (args.length != 2) {
            throw new IllegalArgumentException("Progression takes two arguments");
        }

        boolean isArithmetic = Boolean.parseBoolean(args[0]);
        int num = Integer.parseInt(args[1]);

        if (num < 0) {
            throw new IllegalArgumentException("Number of progression elements should not be negative");
        }

        float step = context.pop();
        float first = context.pop();

        if (isArithmetic) {
            context.push((first + (first +  step * (num - 1))) * num / 2);
        } else {
            if (step == 1) {
                context.push(num * first);
            }
            else {
                context.push((float) (first * (Math.pow(step, num) - 1)) / (step - 1));
            }
        }
    }
}